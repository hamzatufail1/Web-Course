﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bubble_Sort
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arr = new int[6];
            arr[0] = 4;
            arr[1] = 1;
            arr[2] = 6;
            arr[3] = 24;
            arr[4] = 68;
            arr[5] = 91;
            for (int i = 0; i < arr.Length; i++)
            {
                Console.Write(" " + arr[i]);
            }
            Console.WriteLine();
            for (int j = 0; j < arr.Length - 1; j++)
            {
                for (int i = 0; i < arr.Length - 1; i++)
                {
                    if (arr[i] > arr[i + 1])
                    {
                        int a = arr[i];
                        arr[i] = arr[i + 1];
                        arr[i + 1] = a;
                    }
                }
                for (int i = 0; i < arr.Length; i++)
                {
                    Console.Write(" " + arr[i]);
                }
                Console.WriteLine();
            }

            for (int i = 0; i < arr.Length; i++)
            {
                Console.Write(" " + arr[i]);
            }
        }
    }
}
