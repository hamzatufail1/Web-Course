﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace payroll_Calculation_System
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee obj1 = new Employee();
        }
    }
    class Employee
    {
        int[] x;

    }
    class PartTimeEmployee:Employee
    {
        public int calculatesalary(int hourlyrate, int hours)
        {
            Console.WriteLine("Enter Hourly Rate");
            hourlyrate = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter hours of work");
            hours = Convert.ToInt32(Console.ReadLine());
            hourlyrate = hourlyrate * hours;
            return hourlyrate;
        }
    }
    class FullTimeEmployee:Employee
    {
        public int calculatesalary(int basicsalary, int bonus)
        {
            Console.WriteLine("Enter basic Salary of Employee");
            basicsalary = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter bonus");
            bonus = Convert.ToInt32(Console.ReadLine());
            bonus = bonus * basicsalary;
            return bonus;
        }
    }
}
