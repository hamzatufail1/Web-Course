﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Palindrome
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = 0;
            int r = 0;
            int sum = 0;
            int temp = 0;
            Console.Write("Enter the Number: ");
            n = Convert.ToInt32(Console.ReadLine());
            temp = n;
            while (n > 0)
            {
                r = n % 10;
                sum = (sum * 10) + r;
                n = n / 10;
            }
            if (temp == sum)
            {
                Console.WriteLine("Number is Palindrome.");
            }
            else
            {
                Console.WriteLine("Number is not Palindrome");
            }
        }
    }
}
