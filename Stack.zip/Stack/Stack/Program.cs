﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Stack
{
    class Program
    {
        static void Main(string[] args)
        {
            Stack<int> st = new Stack<int>();
            for (int i = 0; i < 5; i++)
            {
                st.Push(Convert.ToInt32(Console.ReadLine()));
            }
            Console.WriteLine("Element Pop");
            Console.WriteLine(st.Pop());
            Console.WriteLine("Next Element to Pop");
            Console.WriteLine(st.Peek());
            Console.WriteLine("Element Pop");
            Console.WriteLine(st.Pop());
        }
    }
}
